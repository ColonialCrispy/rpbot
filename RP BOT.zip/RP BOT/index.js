const discord = require ('discord.js');
const money = require('discord-money');

var client = new discord.Client(); 

const token = "NDYwMTc4MDc0NDQ1NTQ1NDcy.DhA9xQ.rTIR-aLlpJgEIq1IMubpmDAOx0s";

client.on ("ready", () => {
    console.log ("rp bot ready for action"); 

    client.user.setActivity ("r!help | Made by Colonial Mapper")
    client.user.setAvatar(`https://i.imgur.com/brVjgY8.png`)
    client.user.setUsername(`Testing bot`)
});

const prefix = "r!";
client.on ("message", (message) => {
    let cont = message.content.slice(prefix.length).split(" "); // This variable slices off the prefix, then puts the rest in an array based off the spaces
    let args = cont.slice(1);
    
    

    if (message.content.startsWith(`r!create`)) {
        if(!message.member.hasPermission(`MANAGE_CHANNELS`, `MANAGE_MESSAGES`)) return message.channel.send(`:CrowThink:`)
        let args3 = message.content.split(" ").splice(1);
        message.channel.send(`**${args3}** \n \n 1) \n 2) \n 3) \n 4) \n 5) \n 6) \n 7) \n 8) \n 9) \n 10 \n \n  @everyone a new tournament is started and is being hosted by ${message.author.username} dm them if you want to join the rp!  `)
    }

    if (message.content.startsWith(`r!say`)) {
        const sayMessage = args.join(" ");
        message.channel.send(sayMessage)
    }

    if (message.content.startsWith(`r!decide`)) {
        number = 2;
        var random = Math.floor (Math.random() * (number - 1 + 1)) + 1;
        switch (random) {
            case 1: (message.channel.send("They said yes.")); break;
            case 2: (message.channel.send("They said no.")); break;
            case 3: (message.channel.send("They said no.")); break;
        }
    }

    if (message.content.startsWith(`r!help`)) {
        var embed = new discord.RichEmbed()
        embed.addField(`r!help`, `Takes you back here.`)
        embed.addField(`r!create`, `Creates an rp.`)
        embed.addField(`r!decide`, `Decides a decission at random for a nation.`)
        embed.addField(`r!join`, `joins a current RP`)
        embed.setColor(`RANDOM`)
        message.channel.send(embed)
    }
    
    if (message.content.startsWith(`r!role`)){
        const sayMessage = args.join(" ");
        message.guild.createRole({
            name: `${sayMessage}`,
            color: 'RANDOM'
        })
        let lRole = message.guild.roles.find(`${sayMessage}`, `role`);
        lRole.setPermission(`KICK_MEMBERS`)
        message.channel.send(`Created the role ${sayMessage} it's color is random`)
            .then(role => console.log(`Created new role with name ${sayMessage} and color ${sayMessage}`))
            .catch(console.error)


    }

    if (message.content.startsWith(`r!newrole`)){
        const sayMessage = args.join(" ");
        if(!message.member.hasPermission(`MANAGE_ROLES`)) return message.channel.send(`You can't do that! :thinking:`);
        message.guild.createRole({
            name: `${sayMessage}`,
            color: 'RANDOM',
        })
        const cembed = new discord.RichEmbed()
        cembed.setThumbnail(message.guild.iconURL)
        cembed.setColor(`RANDOM`)
        cembed.setTitle(`The role ${sayMessage} has been created!`)
        cembed.addField(`Name:`, ` ${sayMessage}`)
        cembed.addField(`Created by:`, `${message.author.tag}`)
        cembed.addField(`Color: `, `RANDOM`)
        cembed.setTimestamp()
        cembed.setFooter(`Create by ${message.author.tag}`, message.author.avatarURL)
        message.channel.send(cembed)
        message.channel.send(`Created the role ${sayMessage} it's color is random`)
            .then(role => console.log(`Created new role with name ${sayMessage} and color ${sayMessage}`))
            .catch(console.error)
    }

    if (message.content.startsWith(`r!editrole`)) {
        if(!message.member.hasPermission(`MANAGE_ROLES`)) return message.channel.send(`You can't do that! :thinking:`);
        const sayMessage = args.join(" ");
        let eRole = message.guild.roles.find(`name`, sayMessage);
        if (!eRole) return message.channel.send(`Cannot find the role ${sayMessage}`);
        eRole.setPermissions([`KICK_MEMBERS`, `MANAGE_ROLES`])

        const args2 = cont.slice(2);
        const pMessage = args2.join(" ");

        const invitePerm = `CREATE_INSTANT_INVITE`;
        const kickPerm = `KICK_MEMBERS`;
        const banPerm = `BAN_MEMBERS`;
        const administratorPerm = `ADMINISTRATOR`;
        const managechannelPerm = `MANAGE_CHANNELS`;
        const manageguildPerm = `MANAGE_GUILD`;
        const addReactionsPerm = `ADD_REACTIONS`;
        const auditPerm = `VIEW_AUDIT_LOG`;
        const viewchannelPerm = `VIEW_CHANNEL`;
        const sendMessagePerm = `SEND_MESSAGES`;
        const ttsPerm = `SEND_TTS_MESSAGES`;
        const manageMessagesPerm = `MANAGE_MESSAGES`;
        const embedPerm = `EMBED_LINKS`;
        const attachfilesPerm = `ATTACH_FILES`;
        const historyPerm = `READ_MESSAGE_HISTORY`;


        if (pMessage = invitePerm) {

        }
    }

    if (message.content.startsWith(`r!balance`)) {
        money.fetchBal(message.author.id).then((i) => {
            message.channel.send(`**Balance:** ${i.money}`);
        })
    }

    if (message.content.startsWith(`r!give`)) {
        let mUser = message.mentions.users.first();
        let args3 = cont.slice(2);
        money.updateBal(mUser.id, args3 /* Value */).then((i) => {
            message.channel.send(`**${mUser.username} got $${args3} from ${message.author.username}**\n**New Balance:** ${i.money}`); 
        })
    }

    if (message.content.startsWith(`r!pay`)) {
        let mUser = message.mentions.users.first();
        let args3 = cont.slice(2);
        money.updateBal(mUser.id, args3 /* Value */).then((i) => {
            message.channel.send(`Money recieved!`)
        })

        money.updateBal(message.author.id, -args3 /* Value */).then((i) => {
            message.channel.send(`Your new balance is ${i.money}!`)
        })
    }

    if (message.content.startsWith(`r!fine`)) {
        if(!message.member.hasPermission("ADMINISTRATOR")) return message.channel.send(`u aint high enough. cum back later`)
        let mUser = message.mentions.users.first();
        let args4 = cont.slice(2);
        money.updateBal(mUser.id, -args3 /* value */).then((i) => {
            message.channel.send(`**${mUser.username} was fined ${args3} by ${message.author.username}**\n**New Balance:** ${i.money}`);

        })
    }



    if (message.content.startsWith(`r!join`)) {
        let rMember = message.guild.member(message.mentions.users.first())
        if (!message.member.hasPermission("MANAGE_ROLES")) return message.channel.send("lol ur not high enough :crowthink:")
        let aRole = message.guild.roles.find(`role`, `World RP Player`);
        if (!aRole) return message.channel.send(`I can't find the role. :crowthink:`);

        if (rMember.roles.has(aRole.id)) return message.channel.send("The user already have this role!");

        rMember.addRole(aRole.id)


    }

    if (message.content.startsWith(`r!test`)) {
        var tResponse = " ";
        message.channel.send(`go away or oof`);

        channel.awaitMessages(``)
        
        if (tResponse === `go away`) {
            message.channel.send(`u bi bi >:(`)
        }
        if (tResponse === `oof`) {
            message.channel.send(`hi!`)
        }
 
    }
    

});

client.login (token);
